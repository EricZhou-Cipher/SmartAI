# 项目文档

## 1. ARCHITECTURE.md

系统整体架构设计，包括前后端、AI、数据流、技术选型等

## 2. PROMPT_GUIDE.md

AI 调用的 Prompt 模板设计思路+示例 Prompt

## 3. README.md

文档首页，引导说明
