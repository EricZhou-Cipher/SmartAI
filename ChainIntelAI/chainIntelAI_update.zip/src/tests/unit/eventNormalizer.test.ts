describe('normalizeTransferEvent', () => {
  it('should normalize a transfer event', () => {
    const rawEvent = {
      // ... existing code ...
    };

    const normalized = normalizer.normalizeTransferEvent(1, rawEvent);

    // ... existing code ...
  });
});

describe('normalizeContractCall', () => {
  it('should normalize a contract call event', () => {
    const rawEvent = {
      // ... existing code ...
    };

    const normalized = normalizer.normalizeContractCall(1, rawEvent);

    // ... existing code ...
  });
}); 